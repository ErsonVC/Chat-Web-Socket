export interface ChatMessage {
    message: string;
    user: string;
}